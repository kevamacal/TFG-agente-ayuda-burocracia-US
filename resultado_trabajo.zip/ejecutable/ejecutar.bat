@echo off
title Lanzamiento rapido - Agente Conversacional TFG (US)
echo =================================================================
echo    Lanzamiento rapido - Agente Conversacional TFG (Universidad de Sevilla)
echo =================================================================
echo.

:: Comprobar si Docker está instalado
where docker >nul 2>nul
if %errorlevel% neq 0 (
  echo Error: Docker no esta instalado en el sistema. Por favor, instale Docker Desktop primero.
  pause
  exit /b 1
)

:: Comprobar si existe el archivo .env, si no, copiarlo de .env.example
if not exist .env (
  if exist .env.example (
    echo Aviso: No se detecto el archivo .env. Creando uno a partir de .env.example...
    copy .env.example .env
    echo IMPORTANTE: Se ha creado el archivo .env. Por favor, editelo e introduzca
    echo sus credenciales de API (Groq, Pinecone y Cohere) antes de continuar.
  ) else (
    echo Error: No se encuentra .env ni .env.example. Asegurese de que estan en este directorio.
    pause
    exit /b 1
  )
)

echo Iniciando contenedores con Docker Compose...
docker compose up -d

echo.
echo Servicios levantados con exito!
echo -----------------------------------------------------------------
echo Acceso a la aplicacion:
echo   - Chat (Frontend): http://localhost:8501
echo   - Documentacion de API (Backend): http://localhost:8000/docs
echo   - Trazabilidad Langfuse: http://localhost:3000
echo -----------------------------------------------------------------
echo Para detener la aplicacion ejecute: docker compose down
echo.
pause
