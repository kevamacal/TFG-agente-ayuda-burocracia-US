#!/bin/bash
echo "================================================================="
echo "   Lanzamiento rápido - Agente Conversacional TFG (Universidad de Sevilla)"
echo "================================================================="
echo ""

# Comprobar si Docker está instalado
if ! [ -x "$(command -v docker)" ]; then
  echo "Error: Docker no está instalado en el sistema. Por favor, instálelo primero." >&2
  exit 1
fi

# Comprobar si existe el archivo .env, si no, copiarlo de .env.example
if [ ! -f .env ]; then
  if [ -f .env.example ]; then
    echo "Aviso: No se detectó el archivo .env. Creando uno a partir de .env.example..."
    cp .env.example .env
    echo "¡IMPORTANTE!: Se ha creado el archivo .env. Por favor, edítelo e introduzca"
    echo "sus credenciales de API (Groq, Pinecone y Cohere) antes de continuar."
  else
    echo "Error: No se encuentra .env ni .env.example. Asegúrese de que están en este directorio."
    exit 1
  fi
fi

echo "Iniciando contenedores con Docker Compose..."
docker compose up -d

echo ""
echo "¡Servicios levantados con éxito!"
echo "-----------------------------------------------------------------"
echo "Acceso a la aplicación:"
echo "  - Chat (Frontend): http://localhost:8501"
echo "  - Documentación de API (Backend): http://localhost:8000/docs"
echo "  - Trazabilidad Langfuse: http://localhost:3000"
echo "-----------------------------------------------------------------"
echo "Para detener la aplicación ejecute: docker compose down"
echo ""
